from utils.imports import *

bot = Bot(token = TOKEN)
dp = Dispatcher(bot)


@dp.message_handler(commands=['start'])
async def start (message: types.Message):
    await bot.send_message(message.from_user.id, "Приветствую тебя в боте, forum -> https://anonymcheats.ru/")




def get_time():

    global time
    
    time = datetime.datetime.now()



@dp.message_handler(commands=['time'])
async def time (message: types.Message):
    get_time()
    str_time = str(time)
    await bot.send_message(message.from_user.id, f"Сейчас: {str_time}, forum -> https://anonymcheats.ru/")



if __name__ == '__main__': 
    executor.start_polling(dp, skip_updates=True)